module.exports = {
	name: 'unblacklist',
	description: 'un-blacklists user from all SH games',
	execute(suspect, message, firebase) {
		const nbx = require('noblox.js');
    async function exec() {
    const userId = await nbx.getIdFromUsername(suspect).catch(e => "User not found");
    if (userId !== "User not found") {
      const playerName = await nbx.getUsernameFromId(userId)
      var ref = firebase.database().ref("Bans/");
      ref.once("value")
      .then(function(snapshot) {
        var isBanned = snapshot.child(userId).hasChildren()

        if (isBanned !== false){
          var ref2 = firebase.database().ref("Bans/"+userId);
          ref2.remove()
          return message.channel.send("I have successfully unblacklisted **"+playerName+"** from all of Summary's places.")
        } else {
          return message.channel.send("User not blacklisted.")
        }
      })
    }
    }
    exec()
	},
};                                 
