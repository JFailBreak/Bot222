module.exports = {
	name: 'blacklist',
	description: 'blacklistes user from all SH games',
	execute(suspect, reason, message, database) {   

    const nbx = require('noblox.js');
    async function exec() {
      const userId = await nbx.getIdFromUsername(suspect).catch(e => "User not found");
      if (userId !== "User not found") {
        const playerName = await nbx.getUsernameFromId(userId)
        var ref = database.ref("Bans");
        var usersRef = ref.child(userId);
        usersRef.set({
          Moderator: message.member.user.tag,
          Reason: reason
          });
          return message.channel.send("I have successfully blacklisted **"+playerName+"** from all of Summary's places.")
      } else {
        return message.channel.send("Username supplied is invalid.")
      }
      }
      exec()
	},
}; 
